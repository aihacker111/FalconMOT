import copy
import os
import json

import numpy as np
os.environ['CUDA_DEVICE_ORDER'] = 'PCI_BUS_ID'
import torch
import torch.utils.data
from torchvision.transforms import transforms as T

import _paths  # noqa: F401  (sys.path bootstrap)
from falconmot.opts import opts
from falconmot.models.model import create_model, load_model, save_model
from falconmot.models.data_parallel import DataParallel
from falconmot.logger import Logger
from falconmot.datasets.dataset_factory import get_dataset
from falconmot.engine.train_factory import train_factory
from falconmot.engine import stage as stage_mgr
from falconmot.optim import build_optimizer, build_scheduler
from falconmot.utils.jde_eval import CocoJsonEvaluator
from falconmot.models.falcon_jde.postprocessor import FalconJDEPostProcessor
from collections import defaultdict as _defaultdict
from falconmot.tracker.multitracker import MCJDETracker, MCTrack
from falconmot.tracking_utils.coco_gt_reader import CocoGTEvaluator
from falconmot.tracking_utils.evaluation import Evaluator
from falconmot.datasets.dataset.coco_detection import LoadCocoSequencesForTracking


def _with_lr(opt, lr):
    """Shallow copy of opt with a different base lr (for per-phase optimizer)."""
    o = copy.copy(opt)
    o.lr = lr
    return o


def _print_stage1_banner(opt):
    if not getattr(opt, 'train_single_det', False):
        return
    w, h = opt.input_wh[0], opt.input_wh[1]
    es = getattr(opt, 'eval_spatial_size', [h, w])
    print('=' * 72)
    print('Stage-1 detection-only training  (--train_single_det)')
    print(f'  input {w}x{h}  eval_spatial_size={es}  use_s4={getattr(opt, "use_s4", False)} '
          f'use_s4_aux={getattr(opt, "use_s4_aux", True)}')
    print(f'  losses: cls + bbox + giou'
          f"{' + s4_aux' if (getattr(opt, 'use_s4', False) and getattr(opt, 'use_s4_aux', True)) else ''}  |  "
          f'ReID: OFF')
    print(f'  aug: mosaic={getattr(opt, "mosaic", False)} '
          f'(p={getattr(opt, "mosaic_prob", 0.5)})  '
          f'temporal_mosaic=OFF')
    if getattr(opt, 'deim_pretrained', ''):
        print(f'  deim_pretrained: {opt.deim_pretrained}')
    print('  stage-2: load checkpoint WITHOUT --train_single_det')
    print('=' * 72)


def _summarize_model(model, opt):
    core = model.module if hasattr(model, 'module') else model
    print(f'[model] use_s4={getattr(core, "use_s4", False)}  '
          f'use_s4_aux={getattr(core, "use_s4_aux", False)}  '
          f'use_reid={getattr(core, "use_reid", False)}  '
          f's4_branch={hasattr(core, "s4_branch")}  '
          f'reid_head={hasattr(core, "reid_head")}')
    if getattr(opt, 'train_single_det', False) and getattr(opt, 'use_s4', False) \
            and getattr(opt, 'deim_pretrained', ''):
        print('[model] NOTE: s4_branch/s4_aux_head not in DEIM pretrained — '
              'trained from scratch in stage-1.')


@torch.no_grad()
def run_coco_eval(model, val_loader, opt, ann_file: str = '') -> dict:
    """COCO mAP evaluation on the val split."""
    model.eval()

    postprocessor = FalconJDEPostProcessor(
        num_classes=opt.num_classes,
        num_top_queries=500,
        use_focal_loss=True,
        conf_thres=0.0
    )

    evaluator = CocoJsonEvaluator(ann_file) if ann_file else JDECocoEvaluator(
        num_classes=opt.num_classes,
        net_h=opt.input_wh[1],
        net_w=opt.input_wh[0],
    )

    max_batches = getattr(opt, 'debug_val_batches', 0)

    for i, batch in enumerate(val_loader):
        if max_batches > 0 and i >= max_batches:
            break
        batch = {k: v.to(opt.device, non_blocking=True)
                 if isinstance(v, torch.Tensor) else v
                 for k, v in batch.items()}

        orig_hw    = batch.get('orig_hw')
        orig_sizes = orig_hw if orig_hw is not None else \
                     torch.tensor([[opt.input_wh[1], opt.input_wh[0]]] * batch['input'].shape[0],
                                  device=opt.device)

        outputs    = model(batch['input'])
        dt_results = postprocessor(outputs, orig_sizes)
        evaluator.update(dt_results, batch)

    model.train()
    return evaluator.summarize()


@torch.no_grad()
def run_track_eval(model, opt, val_ann_file: str, val_img_root: str) -> dict:
    """Tracking validation (IDF1/MOTA) over val sequences.

    Uses the native class space without any class remap. GMC is disabled for
    speed and determinism (set_image is never called). Returns a dict with
    keys: idf1, mota, num_switches, track_score, fps.
    """
    import time

    if not (val_ann_file and val_img_root and os.path.isfile(val_ann_file)):
        print('[track-eval] missing val_ann/val_img -- skipping tracking eval.')
        return {}

    model.eval()
    net_w, net_h = opt.img_size
    ncls     = opt.num_classes
    min_area = getattr(opt, 'min_box_area', 100)
    _OFF     = 1_000_000

    postproc = FalconJDEPostProcessor(
        num_classes=ncls,
        num_top_queries=getattr(opt, 'K', 300),
        conf_thres=opt.conf_thres,
        use_focal_loss=True,
    )

    opt_trk = copy.copy(opt)
    opt_trk.num_classes = ncls
    tracker = MCJDETracker(opt_trk, frame_rate=getattr(opt, 'frame_rate', 30))

    src = LoadCocoSequencesForTracking(val_ann_file, val_img_root, img_size=opt.img_size)

    accs, names = [], []
    t0, n_frames = time.time(), 0

    for seq_id in src.seqs:
        tracker.reset()
        ev = CocoGTEvaluator(val_ann_file, seq_id)
        ev.reset_accumulator()

        for frame_id, img, img0 in src.sequence(seq_id):
            orig_h, orig_w = img0.shape[:2]
            sizes = torch.tensor([[orig_h, orig_w]], device=opt.device)
            blob  = torch.from_numpy(img[None]).to(opt.device)

            output = model(blob)
            res = postproc(output, sizes)[0]

            dets = _defaultdict(list)
            if len(res['scores']) > 0:
                bxs = res['boxes'].float().cpu().numpy()
                scs = res['scores'].float().cpu().numpy()
                lbs = res['labels'].cpu().numpy()
                rid = res['reid'].float().cpu().numpy() if 'reid' in res else None
                ws  = bxs[:, 2] - bxs[:, 0]
                hs  = bxs[:, 3] - bxs[:, 1]
                for i in np.where((ws > 0) & (hs > 0))[0]:
                    c = int(lbs[i])
                    if c < 0 or c >= ncls:
                        continue
                    tlwh = np.array([bxs[i, 0], bxs[i, 1], ws[i], hs[i]], dtype=np.float32)
                    emb  = rid[i] if rid is not None else np.zeros(1, dtype=np.float32)
                    dets[c].append(MCTrack(tlwh, float(scs[i]), emb, ncls, c))

            online = tracker.update(dets, h_orig=orig_h, w_orig=orig_w)

            tlwhs, tids = [], []
            for c, tracks in online.items():
                for t in tracks:
                    w, h = t.curr_tlwh[2], t.curr_tlwh[3]
                    if t.track_id < 0 or (w * h) <= min_area:
                        continue
                    tlwhs.append(t.curr_tlwh)
                    tids.append(int(t.track_id) + c * _OFF)
            ev.eval_frame(int(frame_id), tlwhs, tids)
            n_frames += 1

        accs.append(ev.acc)
        names.append(seq_id)

    model.train()

    if not accs:
        return {}

    summary = Evaluator.get_summary(
        accs, names, metrics=('mota', 'num_switches', 'idf1', 'idp', 'idr'))
    row  = summary.loc['OVERALL']
    idf1 = float(row['idf1'])
    mota = float(row['mota'])
    nsw  = int(row['num_switches'])
    w_id = float(getattr(opt, 'track_val_w_idf1', 0.6))
    w_mo = float(getattr(opt, 'track_val_w_mota', 0.4))
    fps  = n_frames / max(1e-6, time.time() - t0)
    return {
        'idf1': idf1, 'mota': mota, 'num_switches': nsw,
        'track_score': w_id * idf1 + w_mo * mota, 'fps': fps,
    }


def run(opt):
    _print_stage1_banner(opt)
    torch.manual_seed(opt.seed)
    torch.backends.cudnn.benchmark = not opt.not_cuda_benchmark and not opt.test

    print('Setting up data...')
    Dataset      = get_dataset(opt.dataset, opt.task)
    use_coco_fmt = (opt.dataset == 'coco')

    with open(opt.data_cfg) as f:
        data_config  = json.load(f)
    dataset_root = data_config['root']
    print("Dataset root: %s" % dataset_root)

    from falconmot.datasets.dataset.coco_detection import VisDroneCocoDataset

    if use_coco_fmt:
        train_sources = data_config.get('train_sources')
        if not train_sources and getattr(opt, 'merge_val_into_train', False):
            train_sources = [
                {'ann': data_config['train_ann'], 'img': data_config['train_img']},
                {'ann': data_config['val_ann'],   'img': data_config['val_img']},
            ]
            print('[data] merge_val_into_train: merging train + val into the train set')

        if train_sources:
            dataset = VisDroneCocoDataset(opt=opt, sources=train_sources, augment=True)
        else:
            dataset = VisDroneCocoDataset(
                opt=opt, img_root=data_config['train_img'],
                ann_file=data_config['train_ann'], augment=True)
    else:
        dataset = Dataset(opt=opt, root=dataset_root,
                          paths=data_config['train'], img_size=opt.input_wh,
                          augment=True, transforms=T.Compose([T.ToTensor()]))

    opt = opts().update_dataset_info_and_set_heads(opt, dataset)
    print("opt:\n", opt)
    logger = Logger(opt)

    os.environ['CUDA_VISIBLE_DEVICES'] = opt.gpus_str
    print("opt.gpus_str: ", opt.gpus_str)
    opt.device = torch.device('cuda' if opt.gpus[0] >= 0 else 'cpu')

    # ── Val dataset (optional) ──────────────────────────────────────────────
    val_loader   = None
    val_ann_file = ''
    val_img_root = ''

    if getattr(opt, 'merge_val_into_train', False):
        print('[data] merge_val_into_train=True -> skipping val_loader, no COCO eval.')
    elif getattr(opt, 'val_cfg', ''):
        with open(opt.val_cfg) as f:
            val_config = json.load(f)
        val_dataset = None

        if use_coco_fmt:
            val_ann_file = val_config.get('val_ann', '')
            val_img      = val_config.get('val_img', '')
            val_img_root = val_img
            if val_ann_file and val_img:
                val_dataset = VisDroneCocoDataset(
                    opt=opt, img_root=val_img, ann_file=val_ann_file, augment=False)
            else:
                print('[warn] val_cfg missing val_ann/val_img keys for COCO format.')
        else:
            val_root  = val_config.get('root', dataset_root)
            val_paths = val_config.get('val') or val_config.get('test') or []
            if val_paths:
                val_dataset = Dataset(
                    opt=opt, root=val_root, paths=val_paths,
                    img_size=opt.input_wh, augment=False,
                    transforms=T.Compose([T.ToTensor()]))
            else:
                print('[warn] val_cfg provided but no val/test paths found.')

        if val_dataset is not None:
            val_loader = torch.utils.data.DataLoader(
                dataset=val_dataset,
                batch_size=opt.batch_size,
                shuffle=False,
                num_workers=opt.num_workers,
                pin_memory=True,
                drop_last=False,
                persistent_workers=opt.num_workers > 0,
                prefetch_factor=2 if opt.num_workers > 0 else None,
            )
            print(f'Val dataset: {len(val_dataset)} images')

    print('Creating model...')
    model = create_model(opt.arch, opt)
    _summarize_model(model, opt)

    # ── Load checkpoint BEFORE applying freeze policy ───────────────────────
    start_epoch = 0
    if opt.load_model != '':
        loaded = load_model(model, opt.load_model, None, opt.resume, opt.lr, opt.lr_step)
        model = loaded[0] if isinstance(loaded, tuple) else loaded
        if opt.resume:
            try:
                ckpt = torch.load(opt.load_model, map_location='cpu', weights_only=False)
                start_epoch = int(ckpt.get('epoch', 0))
            except Exception:
                start_epoch = 0

    # ── Training stage policy ───────────────────────────────────────────────
    det_only  = getattr(opt, 'train_single_det', False)
    warmup_ep = max(0, getattr(opt, 'reid_warmup_epochs', 0))
    p0_lr     = opt.lr if getattr(opt, 'reid_warmup_lr', -1) <= 0 else opt.reid_warmup_lr

    in_phase1 = det_only or start_epoch >= warmup_ep
    if det_only:
        stage_mgr.apply_det_only(model)
        init_lr = opt.lr
    elif in_phase1:
        stage_mgr.apply_phase1(model, keep_backbone_frozen=False, freeze_norm=False)
        init_lr = opt.lr
    else:
        stage_mgr.apply_phase0(model)
        init_lr = p0_lr

    optimizer = build_optimizer(model, _with_lr(opt, init_lr))

    _nw = opt.num_workers
    train_loader = torch.utils.data.DataLoader(
        dataset=dataset,
        batch_size=opt.batch_size,
        shuffle=True,
        num_workers=_nw,
        pin_memory=True,
        drop_last=True,
        persistent_workers=_nw > 0,
        prefetch_factor=2 if _nw > 0 else None,
    )
    steps_per_epoch = len(train_loader)

    print('Starting training...')
    Trainer = train_factory[opt.task]
    trainer = Trainer(opt=opt, model=model, optimizer=optimizer)
    trainer.set_device(opt.gpus, opt.chunk_sizes, opt.device)

    if in_phase1:
        phase_epochs = max(1, opt.num_epochs - warmup_ep)
    else:
        phase_epochs = warmup_ep if warmup_ep > 0 else opt.num_epochs
    scheduler = stage_mgr.build_phase_scheduler(
        optimizer, opt, build_scheduler, steps_per_epoch, phase_epochs,
        warmup_iters=min(getattr(opt, 'warmup_iters', 2000), steps_per_epoch))

    if in_phase1 and start_epoch > warmup_ep:
        scheduler.fast_forward((start_epoch - warmup_ep) * steps_per_epoch)
    elif (not in_phase1) and start_epoch > 0:
        scheduler.fast_forward(start_epoch * steps_per_epoch)

    best_mAP   = 0.0
    best_track = 0.0

    for epoch in range(start_epoch + 1, opt.num_epochs + 1):
        mark = epoch if opt.save_all else 'last'

        # ── Phase 0 → Phase 1 transition ───────────────────────────────────
        if (not det_only) and (not in_phase1) and epoch > warmup_ep:
            in_phase1 = True
            stage_mgr.apply_phase1(
                model,
                keep_backbone_frozen=getattr(opt, 'keep_backbone_frozen', False),
                freeze_norm=getattr(opt, 'freeze_norm_stats', False))
            optimizer = stage_mgr.build_phase_optimizer(
                model, trainer.loss, opt, build_optimizer, lr=opt.lr)
            trainer.optimizer = optimizer
            trainer.set_device(opt.gpus, opt.chunk_sizes, opt.device)
            scheduler = stage_mgr.build_phase_scheduler(
                optimizer, opt, build_scheduler, steps_per_epoch,
                max(1, opt.num_epochs - warmup_ep),
                warmup_iters=min(getattr(opt, 'warmup_iters', 2000), steps_per_epoch))
            print(f'[stage] >>> switched to Phase 1 (joint) at epoch {epoch}')

        # ── id_weight schedule ──────────────────────────────────────────────
        if det_only:
            trainer.loss.id_weight = 0.0
        elif in_phase1:
            stage_mgr.ramp_id_weight(trainer.loss, opt.id_weight,
                                     epoch - warmup_ep,
                                     getattr(opt, 'id_warmup_epochs', 0))
        else:
            trainer.loss.id_weight = opt.id_weight
        if not det_only:
            logger.write('id_w {:.3f} | '.format(trainer.loss.id_weight))

        train_loader.dataset.set_epoch(epoch - 1)

        log_dict_train, _ = trainer.train(epoch, train_loader, scheduler=scheduler)

        cur_lr = optimizer.param_groups[0]['lr']
        logger.write('epoch: {} |'.format(epoch))
        logger.write('lr {:e} | '.format(cur_lr))
        for k, v in log_dict_train.items():
            logger.scalar_summary('train_{}'.format(k), v, epoch)
            logger.write('{} {:8f} | '.format(k, v))

        # ── Periodic checkpoint ─────────────────────────────────────────────
        if opt.val_intervals > 0 and epoch % opt.val_intervals == 0:
            save_model(os.path.join(opt.save_dir, 'model_{}.pth'.format(mark)),
                       epoch, model, optimizer)
        else:
            save_model(os.path.join(opt.save_dir, 'model_last' + opt.arch + '.pth'),
                       epoch, model, optimizer)

        # ── COCO mAP eval (stage-1 only) ───────────────────────────────────
        if det_only and val_loader is not None and opt.val_intervals > 0 \
                and epoch % opt.val_intervals == 0:
            print(f'\n[Eval] epoch {epoch} — running COCO mAP (stage-1)...')
            metrics = run_coco_eval(model, val_loader, opt, ann_file=val_ann_file)

            log_line = '  '.join(f'{k} {v:.4f}' for k, v in metrics.items())
            print(f'[Eval] {log_line}')
            logger.write(f'[eval] {log_line} | ')
            for k, v in metrics.items():
                logger.scalar_summary(f'val_{k}', v, epoch)

            cur_mAP = metrics.get('AP', 0.0)
            if cur_mAP > best_mAP:
                best_mAP = cur_mAP
                save_model(os.path.join(opt.save_dir, 'model_best.pth'),
                           epoch, model, optimizer)
                print(f'[Eval] ★ New best AP={best_mAP:.4f} → model_best.pth')

        # ── Tracking eval (stage-2 only) ────────────────────────────────────
        _tvi = getattr(opt, 'track_val_intervals', 0) or opt.val_intervals
        do_track = (
            (not det_only)
            and getattr(opt, 'track_val', False)
            and val_ann_file and val_img_root
            and opt.val_intervals > 0
            and epoch % max(1, _tvi) == 0
        )
        skip_p0 = (not in_phase1) and not getattr(opt, 'track_val_in_phase0', False)
        if do_track and not skip_p0:
            print(f'\n[Track-Eval] epoch {epoch} — running tracking IDF1/MOTA (GMC off)...')
            tmetrics = run_track_eval(model, opt, val_ann_file, val_img_root)
            if tmetrics:
                tline = (f"IDF1 {tmetrics['idf1']:.4f}  MOTA {tmetrics['mota']:.4f}  "
                         f"IDsw {tmetrics['num_switches']}  "
                         f"score {tmetrics['track_score']:.4f}  "
                         f"({tmetrics['fps']:.1f} fps)")
                print(f'[Track-Eval] {tline}')
                logger.write(f'[track] {tline} | ')
                logger.scalar_summary('val_idf1', tmetrics['idf1'], epoch)
                logger.scalar_summary('val_mota', tmetrics['mota'], epoch)
                logger.scalar_summary('val_idsw', tmetrics['num_switches'], epoch)
                logger.scalar_summary('val_track_score', tmetrics['track_score'], epoch)

                if tmetrics['track_score'] > best_track:
                    best_track = tmetrics['track_score']
                    save_model(os.path.join(opt.save_dir, 'model_best.pth'),
                               epoch, model, optimizer)
                    print(f"[Track-Eval] ★ New best track_score={best_track:.4f} "
                          f"(IDF1={tmetrics['idf1']:.4f}, MOTA={tmetrics['mota']:.4f}) "
                          f"→ model_best.pth")

        logger.write('\n')

        if epoch in opt.lr_step:
            save_model(os.path.join(opt.save_dir, 'model_{}.pth'.format(epoch)),
                       epoch, model, optimizer)

        if epoch % 5 == 0 or epoch >= 25:
            save_model(os.path.join(opt.save_dir, 'model_{}.pth'.format(epoch)),
                       epoch, model, optimizer)

    logger.close()


if __name__ == '__main__':
    opt = opts().parse()
    print("opt.gpus: ", opt.gpus)
    print('epoch:', opt.num_epochs)
    run(opt)
